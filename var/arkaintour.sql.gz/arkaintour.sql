-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 03, 2012 at 03:14 PM
-- Server version: 5.0.92
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arkain_nasbg`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `lang_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `default` tinyint(3) unsigned NOT NULL default '0',
  `script_id` int(10) unsigned NOT NULL default '1',
  `show_title` tinyint(3) unsigned NOT NULL default '1',
  `order` smallint(5) unsigned NOT NULL,
  `added` datetime NOT NULL,
  `added_by` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `script_id` (`script_id`),
  KEY `url` (`url`),
  FULLTEXT KEY `Texts` (`title`,`keywords`,`content`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `lang_id`, `title`, `content`, `url`, `keywords`, `default`, `script_id`, `show_title`, `order`, `added`, `added_by`, `modified`, `modified_by`) VALUES
(1, 1, 'Начало', '', 'начало', '', 0, 5, 0, 1, '2012-06-27 10:55:31', 2, '2012-06-27 15:11:50', 2),
(2, 1, 'За нас', '<h2>За нас</h2>\r\n<p><strong>&bdquo;АРКАИН-ТУР&ldquo; ООД</strong> е лицензиран туроператор и туристически агент с удостоверение за регистрация № РКК-01-05908.<br />Туристическа агенция "Аркаин-тур" ООД , с централен офис: гр.Варна, ул. "Братя Шкорпил" №12 предлага голямо разнообразие от <strong>индивидуални и групови туристически услуги</strong>:<br /><br /></p>\r\n<ul>\r\n<li>екскурзии и почивки в страната и чужбина;</li>\r\n<li>конгресен и бизнес туризъм;</li>\r\n<li>програми за ученици;</li>\r\n<li>автобусни и самолети билети;</li>\r\n<li>хотелски резервации;</li>\r\n<li>културен и езотеричен туризъм;</li>\r\n</ul>\r\n<p>Наши партньори са фирми с доказан успех в туризма. Това ни дава възможност освен наши туристически програми, да Ви предложим и тези на водещи туроператори в страната и чужбина.</p>\r\n<p><br />Ние сме млад и изключително ентусиазиран, професионален колектив. Държим на коректността и доброто обслужване към своите клиенти.</p>\r\n<p><br />Свържете се с нас за да подберем най-подходящия туристически продукт за вас и да гарантираме неговото качеството. Кажете ни от какво се нуждаете и ние ще ви предложим наи-доброто!</p>\r\n<p><img style="display: block; margin-left: auto; margin-right: auto;" title="licenz2_400" src="../uploads/licenz2_400.jpg" alt="licenz2_400" width="275" height="400" /></p>', 'за-нас', '', 0, 1, 1, 2, '2012-06-27 10:56:57', 2, '2012-07-03 15:12:00', 2),
(3, 1, 'Контакти', '<h2>За контакти</h2>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 594px; height: 272px; font-size: 0.8em;" border="0" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: center;" rowspan="7"><iframe src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=bg&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A&amp;output=embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" width="380" height="250"></iframe><br /><small><a style="color: #0000ff; text-align: left;" href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A">По-голяма карта</a></small></td>\r\n<td colspan="2">гр. Варна</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2">ул. Братя Шкорпил №12</td>\r\n</tr>\r\n<tr>\r\n<td>Тел.:</td>\r\n<td>052 / 917-486</td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>052 / 605-052</td>\r\n</tr>\r\n<tr>\r\n<td>Skype:</td>\r\n<td><img title="skype" src="uploads/skype.png" alt="skype" width="16" height="16" /> <a href="skype:zvetka26">zvetka26</a></td>\r\n</tr>\r\n<tr>\r\n<td rowspan="2" colspan="2">\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'контакти', '', 0, 3, 1, 5, '2012-06-27 11:13:05', 2, '2012-07-03 13:59:31', 2),
(4, 1, 'Почивки', '', 'почивки', '', 0, 2, 1, 4, '2012-06-27 11:32:09', 2, '2012-06-27 11:32:09', 2),
(5, 1, 'Екскурзии', '', 'екскурзии', '', 0, 2, 1, 3, '2012-06-27 11:32:20', 2, '2012-06-27 15:10:49', 2),
(17, 2, 'Home Page', '', 'home-page', '', 0, 5, 0, 1, '2012-06-27 17:06:01', 2, '2012-06-27 17:06:01', 2),
(18, 2, 'About Us', '<h2>About Us</h2>\r\n<p>"ARKAIN TOUR" is an a licenced tour operator and yourist agency with certificate number РКК-01-05908. Our central office is localized in Varna, Bulgaria "Bratia Shkorpil" street number 12 and we offer a range of the following individual and group tourist services:<br /><br /></p>\r\n<ul>\r\n<li>travel in Bulgaria and abroad;</li>\r\n<li>congress and business tourism;</li>\r\n<li>student programs;</li>\r\n<li>bus and aircraft tickets;</li>\r\n<li>hotel reservations;</li>\r\n<li>cultural and exotic tourism;</li>\r\n</ul>\r\n<p><br />We have partners with proven success in the tourism branch. This gives us the opportunity to offer you not only our tourist programs but we can also give you offers from other agencies in the country and abroad.<br /><br />We are a young, enthusiastic and professional team. Our main target is to be correct with our customers and to offer them the best services.<br /><br />Please contat us so we can find out which tourism product fits your interests best and guarantee you its quality. Tell us what you need and we will offer you the best!</p>\r\n<p>&nbsp;</p>', 'about-us', '', 0, 1, 1, 2, '2012-06-27 17:06:22', 2, '2012-07-03 15:11:22', 2),
(19, 2, 'Contacts', '<h2>Contact Us</h2>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 594px; height: 272px; font-size: 0.8em;" border="0" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: center;" rowspan="8"><iframe src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A&amp;output=embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" width="380" height="250"></iframe><br /><small><a style="color: #0000ff; text-align: left;" href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A">Larger Map</a></small></td>\r\n<td colspan="2">9000 Varna</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2">12 Bratia Schkorpil</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2">Bulgaria</td>\r\n</tr>\r\n<tr>\r\n<td>Phone:</td>\r\n<td>+359 52 917 486</td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>+359 52 605 052</td>\r\n</tr>\r\n<tr>\r\n<td>Skype:</td>\r\n<td><img title="skype" src="uploads/skype.png" alt="skype" width="16" height="16" /> <a href="skype:zvetka26">zvetka26</a></td>\r\n</tr>\r\n<tr>\r\n<td rowspan="2" colspan="2">\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'contacts', '', 0, 3, 1, 5, '2012-06-27 17:37:41', 2, '2012-07-03 13:59:12', 2),
(20, 2, 'Excursions', '', 'excursions', '', 0, 2, 0, 3, '2012-06-28 11:14:50', 2, '2012-07-03 13:57:18', 2),
(21, 2, 'Holiday', '', 'holiday', '', 0, 2, 0, 4, '2012-07-03 13:57:09', 2, '2012-07-03 13:57:09', 2),
(22, 3, 'Главная', '', 'главная', '', 0, 5, 0, 1, '2012-07-03 13:57:39', 2, '2012-07-03 13:57:39', 2),
(23, 3, 'О нас', '<h2>О компании</h2>\r\n<p>"АРКАИН ТУР" является лицензированным туроператором и yourist агентство свидетельство № РКК-01-05908. Наш центральный офис локализован в Варне, Болгария "Братья Шкорпил" улица № 12, и мы предлагаем выбор из следующих индивидуальных и групповых туристических услуг:</p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>путешествие в Болгарии и за рубежом;</li>\r\n<li>конгрессов и делового туризма;</li>\r\n<li>студенческие программы;</li>\r\n<li>автобус и самолет билетов;</li>\r\n<li>бронирование;</li>\r\n<li>культурные и экзотический туризм;</li>\r\n</ul>\r\n<p><br />У нас есть партнеры, доказавших свою успешность в туристической отрасли. Это дает нам возможность предложить Вам не только наши туристические программы, но мы также можем дать вам предложения от других учреждений в стране и за рубежом.<br /><br />Мы молоды, энтузиазма и профессиональная команда. Нашей основной целью является правильным с нашими клиентами и предложить им лучшие услуги.<br /><br />Пожалуйста, contat нас, чтобы мы могли выяснить, какой туристический продукт соответствует вашим интересам лучших и гарантируем Вам качество. Расскажите, что вам нужно, и мы предложим Вам лучшее!</p>', 'о-нас', '', 0, 1, 0, 2, '2012-07-03 13:57:58', 2, '2012-07-03 15:12:58', 2),
(24, 3, 'Экскурсии', '', 'экскурсии', '', 0, 2, 0, 3, '2012-07-03 13:58:15', 2, '2012-07-03 13:58:15', 2),
(25, 3, 'Отдых', '', 'отдых', '', 0, 2, 0, 4, '2012-07-03 13:58:21', 2, '2012-07-03 13:58:51', 2),
(26, 3, 'Контакты', '<h2>Контакты</h2>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 594px; height: 272px; font-size: 0.8em;" border="0" cellpadding="5">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: center;" rowspan="8"><iframe src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=ru&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A&amp;output=embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" width="380" height="250"></iframe><br /><small><a style="color: #0000ff; text-align: left;" href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=%D0%B2%D0%B0%D1%80%D0%BD%D0%B0+%D1%83%D0%BB.+%D1%88%D0%BA%D0%BE%D1%80%D0%BF%D0%B8%D0%BB+12&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=55.411532,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=ulitsa+Bratya+Shkorpil+12,+Varna,+Bulgaria&amp;t=m&amp;ll=43.206638,27.913384&amp;spn=0.001955,0.004077&amp;z=17&amp;iwloc=A">Увеличенную карту</a></small></td>\r\n<td colspan="2">9000 Варна</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2">ул. Братя Шкорпил, 12</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2">Болгария</td>\r\n</tr>\r\n<tr>\r\n<td>Тел.:</td>\r\n<td>+359 52 917 486</td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>+359 52 605 052</td>\r\n</tr>\r\n<tr>\r\n<td>Skype:</td>\r\n<td><img title="skype" src="uploads/skype.png" alt="skype" width="16" height="16" /> <a href="skype:zvetka26">zvetka26</a></td>\r\n</tr>\r\n<tr>\r\n<td rowspan="2" colspan="2">\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'контакты', '', 0, 3, 0, 5, '2012-07-03 13:58:39', 2, '2012-07-03 13:58:39', 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `lang_id` int(10) unsigned NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `added` datetime NOT NULL,
  `added_by` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `article_id` (`article_id`),
  FULLTEXT KEY `Texts` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `lang_id`, `article_id`, `title`, `order`, `added`, `added_by`, `modified`, `modified_by`) VALUES
(15, 1, 5, 'Екскурзии в чужбина', 1, '2012-06-29 10:02:03', 2, '2012-07-03 13:15:43', 2),
(12, 1, 4, 'Почивки в Италия', 1, '2012-06-29 10:01:11', 2, '2012-06-29 10:01:11', 2),
(13, 1, 4, 'Почивки в Турция - Лято 2012', 2, '2012-06-29 10:01:19', 2, '2012-06-29 10:01:41', 2),
(14, 1, 4, 'Абитуриентски балове', 3, '2012-06-29 10:01:54', 2, '2012-06-29 10:01:54', 2),
(16, 1, 5, 'Екскурзии в страната', 2, '2012-06-29 10:02:07', 2, '2012-06-29 10:02:07', 2),
(17, 1, 4, 'Почивки в Чужбина', 4, '2012-06-29 10:02:24', 2, '2012-06-29 10:02:24', 2),
(18, 1, 4, 'Почивки в Страната', 5, '2012-06-29 10:02:32', 2, '2012-06-29 10:02:32', 2),
(19, 1, 5, 'Самолетни и автобусни билети!', 3, '2012-06-29 10:02:43', 2, '2012-06-29 10:02:43', 2),
(20, 1, 4, 'Ученически туризъм', 6, '2012-06-29 10:03:07', 2, '2012-06-29 10:03:07', 2),
(21, 1, 5, 'За Вас Студенти', 4, '2012-06-29 10:04:22', 2, '2012-06-29 10:04:22', 2),
(22, 2, 20, 'Italy', 1, '2012-07-03 13:59:50', 2, '2012-07-03 13:59:50', 2),
(23, 2, 21, 'Spain', 1, '2012-07-03 13:59:54', 2, '2012-07-03 13:59:54', 2),
(24, 3, 25, 'Родопи', 1, '2012-07-03 14:00:13', 2, '2012-07-03 14:00:13', 2),
(25, 3, 24, 'Балчик', 1, '2012-07-03 14:00:36', 2, '2012-07-03 14:00:36', 2);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `lang_code` varchar(2) NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `locale` varchar(10) NOT NULL,
  `native` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL,
  `default` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `locale` (`locale`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `lang_code`, `country_code`, `locale`, `native`, `name`, `active`, `default`) VALUES
(1, 'bg', 'BG', 'bg_BG', 'български', 'Bulgarian', 1, 1),
(2, 'en', 'US', 'en_US', 'English', 'English', 1, 0),
(3, 'ru', 'RU', 'ru_RU', 'Русский', 'Russian', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `lang_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `vip_offer` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `route` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  `added_by` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `category_id` (`category_id`),
  FULLTEXT KEY `Texts` (`name`,`content`,`price`,`route`,`transport`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `lang_id`, `category_id`, `vip_offer`, `name`, `content`, `route`, `duration`, `transport`, `price`, `added`, `added_by`, `modified`, `modified_by`) VALUES
(47, 1, 15, 1, 'УИКЕНД ВЪВ ФЛОРЕНЦИЯ', '<p><span class="content_title"><strong>ПРОГРАМА</strong> <br /> </span> <br /> <span class="content_title"><em>Първи ден:</em> <br /> </span>Кацане на летището. Трансфер до избрания 4* хотел в центъра на града. Свободно време. <br /> <br /> <span class="content_title"><em>Втори ден:</em> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><em>Трети ден:</em> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><em>Четвърти ден:</em> <br /> </span>Закуска. Трансфер до летището. Полет за София. <br /> <br /> Дни по програмата:<br /> Всеки петък <br /> </p>\r\n<table class="wiki_table" border="0" cellspacing="0" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">Период <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Цена на човек в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Допълнително легло в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Единична стая ВВ <br /> </span></td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">02.01.2012 &ndash; 31.03.2012 <br /> </span></td>\r\n<td class="wiki_td">258 евро</td>\r\n<td class="wiki_td">220 евро</td>\r\n<td class="wiki_td">462 евро</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">01.04.2012 &ndash; 30.04.2012; 01.07.2012 &ndash; 04.09.2012 <br /> </span></td>\r\n<td class="wiki_td">327 евро</td>\r\n<td class="wiki_td">281 евро</td>\r\n<td class="wiki_td">530 евро</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">01.05.2012 &ndash; 30.06.2012; 05.09.2012 &ndash; 31.10.2012 <br /> </span></td>\r\n<td class="wiki_td">398 евро</td>\r\n<td class="wiki_td">336 еро</td>\r\n<td class="wiki_td">642 евро</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><br /> <br /> Деца от 0 до 6г. - безплатно <br /> <br /> <span class="content_title"><strong>Цените включват:</strong> <br /> </span> </p>\r\n<ul>\r\n<li>3 нощувки в 4* хотел в центъра на града</li>\r\n<li>3 закуски</li>\r\n<li>трансфер летище &ndash; хотел &ndash; летище</li>\r\n</ul>\r\n<p><br /> <span class="content_title"><strong>Цените не включват:</strong> <br /> </span> </p>\r\n<ul>\r\n<li>самолетен билет София &ndash; Флоренция - София - 150 евро към 21.02.2012 /подлежи на препотвърждение/</li>\r\n</ul>\r\n<p><span class="content_title"><strong>НАСТАНЯВАНЕ ПО ПРОГРАМАТА</strong> <br /> </span><em><strong>Hotel Kraft 4*</strong> </em><br /> Разположен в сърцето на романтичен квартал на Флоренция, на пешеходно разстояние от река Арно, Операта, ж.п.спирка Санта Мария Новела и от главните исторически забележителности. <br /> <br /> <span class="content_title"><strong><em>В стаите:</em> </strong><br /> </span>Хотелът разполага с 80 стаи, от които 71 двойни и 9 единични, всички оборудвани с климатик, мини бар, директна телефонна линия, радио, сателитна телевизия, музикална и видео система/при поискване/, интернет. <br /> <br /> <span class="content_title"><strong><em>В хотела:</em> </strong><br /> </span>Градина на покрива на хотела с басейн /Юни-Септември/, американски бар, ресторант "Terrazza Rossini" с открита площ/през лятото/, конферентна зала, гараж.</p>', 'София – Флоренция - София', '4 дни / 3 нощувки', 'Самолет', '258 €', '2012-06-29 10:28:44', 2, '2012-06-29 10:28:44', 2),
(48, 1, 15, 1, 'УИКЕНД В МИЛАНО', '<p><span class="content_title"><strong>ПРОГРАМА</strong> <br /> </span> <br /> <span class="content_title"><strong>Първи ден:</strong> <br /> </span>Кацане на летището. Трансфер до избрания 4* хотел в центъра на града. Свободно време. <br /> <br /> <span class="content_title"><strong>Втори ден:</strong> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><strong>Трети ден:</strong> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><strong>Четвърти ден:</strong> <br /> </span>Закуска. Трансфер до летището. Полет за София. <br /> <br /> <strong>Дни по програмата:</strong> </p>\r\n<ul>\r\n<li>Всяка неделя / в периода 01.01 до 26.03.2012/</li>\r\n<li>Всеки ден /след 26.03.2012/</li>\r\n<li>Хотел Конкорд 4*</li>\r\n<li>Hotel Concorde 4*</li>\r\n</ul>\r\n<p><br /> </p>\r\n<table class="wiki_table" border="0" cellspacing="0" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">Период <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Цена на човек в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Цена на човек допълнително легло в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Цена на човек единична стая BB <br /> </span></td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">02.01.2012 &ndash; 27.12.2012 <br /> </span></td>\r\n<td class="wiki_td">297 евро</td>\r\n<td class="wiki_td">248 евро</td>\r\n<td class="wiki_td">594 евро</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><br /> Деца от 0 до 6 г. - безплатно <br /> <br /> <span class="content_title"><strong>Цените включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>3 нощувки в 4* хотел в центъра на града</li>\r\n<li>3 закуски</li>\r\n<li>трансфер летище &ndash; хотел &ndash; летище</li>\r\n</ul>\r\n<p><span class="content_title"><strong>Цените не включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>Самолетен билет София &ndash; Милано &ndash; София &ndash; 150 евро към 20.02.2012 /подлежи на препотвърждение/</li>\r\n</ul>\r\n<p><span class="content_title"><strong>НАСТАНЯВАНЕ ПО ПРОГРАМАТА</strong> <br /> </span> <br /> <strong>ANTARES HOTEL CONCORDE 4*</strong> <br /> Хотелът е разположен само на няколко крачки от старите градски порти на Порта Венеция, откъдето започва Corso Buenos Aires &ndash; една от най-дългите шопинг улици в Европа. Централната ж.п. гара е само на 2 км., но хотелът е лесно достъпен и от магистралите и летищата и е само на няколко спирки от спирка Дуомо на метрото. <br /> <br /> <strong>В стаите:</strong> <br /> Хотелът се състои от 120 стаи разположени на 10 етажа, наскоро е напълно реновиран и модернизиран. Всички стаи са шумоизолирани, собствена баня с душ или вана, директна телефонна линия, мини бар, сателитна телевизия с платени канали, климатик, безжичен интернет, сейф и интерактивна система за обслужване на гостите на хотела. <br /> <br /> <strong>В хотела:</strong> <br /> Коктейл бар, ресторант с голям избор на италианска кухня, гараж, пералня, детегледачка, фитнес, 3 конферентни зали.</p>\r\n<p>&nbsp;</p>', 'София - Милано - София', '4 дни / 3 нощувки', 'Самолет', '297 €', '2012-06-29 10:32:27', 2, '2012-06-29 10:32:27', 2),
(49, 1, 15, 0, 'София – Рим – София', '<p><span class="content_title"><strong>ПРОГРАМА</strong> <br /> </span> <br /> 4 дни/3 нощувки <br /> <br /> <span class="content_title"><strong>Първи ден:</strong> <br /> </span>Кацане на летището. Трансфер до избрания 4* хотел в центъра на града. Свободно време. <br /> <br /> <span class="content_title"><strong>Втори ден:</strong> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><strong>Трети ден:</strong> <br /> </span>Закуска. Възможност за допълнителни екскурзии. <br /> <br /> <span class="content_title"><strong>Четвърти ден:</strong> <br /> </span>Закуска. Трансфер до летището. Полет за София. <br /> <br /> Дни по програмата: <br /> Всяка неделя / в периода 01.01 до 25.03.2012/ <br /> Всяка събота /след 25.03.2012/ <br /> Хотел Паладиум Палас 4* </p>\r\n<table class="wiki_table" border="0" cellspacing="0" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">Период <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Цена на човек в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Допълнително легло в двойна стая ВВ <br /> </span></td>\r\n<td class="wiki_td"><span class="content_title">Единична стая BB <br /> </span></td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">02.01.2012 &ndash; 28.02.2012; 01.08.2012 &ndash; 31.08.2012; 01.11.2012 &ndash; 27.12.2012 <br /> </span></td>\r\n<td class="wiki_td">218 евро</td>\r\n<td class="wiki_td">195 евро</td>\r\n<td class="wiki_td">404 евро</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">01.03.2012 &ndash; 31.03.2012; 01.07.2012 &ndash; 31.07.2012 <br /> </span></td>\r\n<td class="wiki_td">241 евро</td>\r\n<td class="wiki_td">241 евро</td>\r\n<td class="wiki_td">438 евро</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td"><span class="content_title">01.04.2012 &ndash; 30.06.2012; 01.09.2012 &ndash; 31.10.2012 <br /> </span></td>\r\n<td class="wiki_td">351 евро</td>\r\n<td class="wiki_td">319 евро</td>\r\n<td class="wiki_td">603 евро</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><br /> Деца от 0 до 4 г. - безплатно <br /> <span class="content_title"><strong>Цените включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>3 нощувки в 4* хотел в центъра на града</li>\r\n<li>3 закуски</li>\r\n<li>трансфер летище &ndash; хотел &ndash; летище</li>\r\n</ul>\r\n<p><span class="content_title"><strong>Цените не включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>самолетен билет София &ndash; Рим &ndash; София &ndash; 150 евро към 21.02.2012 /подлежи на препотвърждение/</li>\r\n</ul>\r\n<p><br /> <br /> <span class="content_title"><strong>НАСТАНЯВАНЕ ПО ПРОГРАМАТА:</strong> <br /> </span> <br /> <strong>PALADIUM PALACE 4*</strong> <br /> Хотелът, някогашен дворец, разположен на 400 м. от гара Термини и само на 100 м. от Базиликата Санта Мария Маджоре се откроява със своята елегантност, комфорт и добро обслужване. На разположение на гостите са фитнес, малка конферентна зала и прекрасна панорамна тераса с гледка към Рим. Хотелът е подходящ както за туристи, така и за бизнес гости. <br /> В стаите: Хотелът разполага с 81 стаи от които 54 Класик, 13 Сюпириър, 6 Делукс , 1 Джуниър Сюит, 1 Апартамент и 3 специално оборудвани за инвалиди. <br /> Всички стаи са модерно оборудвани, а Класик, Сюпириър, Делукс и Джуниър Сюит са обрудвани и с джакузи, вана и DVD плеър. Предлагат се единични, двойни, тройни и четворни стаи, като всички имат безплатна интернет връзка, сателитна телевизия с безплатни канали, телефон, мини бар, сейф, климатик и плей стейшън. <br /> Услуги: Безжичен интернет, конферентна зала, факс, преса, трансфери, туристическа информация, екскурзии, пералня.</p>', 'София – Рим – София', '4 дни / 3 нощувки', 'Самолет', 'от 195 €', '2012-06-29 10:35:34', 2, '2012-06-29 10:35:59', 2),
(50, 1, 15, 0, '55+ и приятели - ИСПАНИЯ, Коста дел Сол', '<p><span class="content_title"><strong>1-ви ден (петък):</strong> <br /> </span>чартърен полет от София за Малага. Трансфер до хотела и настаняване. <br /> Свободно време. Вечеря. Нощувка.</p>\r\n<p><br /> <span class="content_title"><strong>2-ри &ndash; 7-ми ден:</strong> <br /> </span>Закуска. Свободно време. Възможност за допълнителни екскурзии (срещу <br /> допълнително заплащане на място). В някои от дните на престоя &ndash; екскурзия до Малага и Михас (типично селце в стила на Андалусия) с екскурзовод на български език и втора екскурзия - разходка до Гибралтар със свободно време за разходка (включени в цената). Вечеря. Нощувка.</p>\r\n<p><br /> <span class="content_title"><strong>8-ми ден (петък):</strong> <br /> </span>Закуска. Свободно време. Трансфер до летище Малага за полет до София. <br /> <br /> <span class="content_title"><strong>Цените включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>Самолетен билет с чартърен полет София-Малага-София</li>\r\n<li>Трансфери с автобус летище &ndash; хотел &ndash; летище</li>\r\n<li>7 нощувки в хотел 4 * в курортите на Коста дел Сол на база пълен пансион на блок маса (закуска, обяд и вечеря с включени вода и вино)</li>\r\n<li>Екскурзия до Малага и Михас на български език</li>\r\n<li>Екскурзия до Гибралтар</li>\r\n<li>Медицинска застраховка</li>\r\n</ul>\r\n<p><br /> <span class="content_title"><strong>Цените не включват:</strong> <br /> </span></p>\r\n<ul>\r\n<li>Летищни такси &ndash; 45 евро / 88 лева</li>\r\n<li>Разходи от лично естество</li>\r\n</ul>\r\n<p><br /> <span class="content_title">Условия за плащане <br /> </span></p>\r\n<ul>\r\n<li>Условия за плащане по специални цени до 26.12.2011!</li>\r\n</ul>\r\n<p>депозит &ndash; 50 % от пакетната цена до 26.12.2012; доплащане &ndash; 20 работни дни преди отпътуване </p>\r\n<ul>\r\n<li>Условия за плащане по цените, валидни от 27.12.2012 (+100 лева от посочените цени):</li>\r\n</ul>\r\n<p>депозит &ndash; 50% от цената до 31 януари 2012; доплащане &ndash; 20 работни дни преди отпътуване <br /> <br /> <span class="content_title"><strong>Необходими документи:</strong> <br /> </span></p>\r\n<ul>\r\n<li>Копие от лична карта или международен паспорт, с валидност минимум 6 месеца от датата на пътуване</li>\r\n<li>Няма визови, санитарни и медицински изисквания за пътуване в страната</li>\r\n</ul>\r\n<p><br /> <span class="content_title">ПРИМЕРНИ ХОТЕЛИ ПО ПРОГРАМАТА: <br /> </span></p>\r\n<ul>\r\n<li>NH MARBELLA 4 *, http://www.nh-hotels.com/</li>\r\n<li>LAS PALOMAS 4 * Торемолинос, http://www.laspalomas.es/</li>\r\n<li>LOS PATOS 4 * Беналмадена, http://www.hotellospatos.com/</li>\r\n<li>VISTA MAR 4 * Беналмадена, http://www.malagaholidays.com/apartments/malaga/benalmadena/vistamar-apartments/</li>\r\n<li>HOTEL EL PINAR 4 * Торемолинос, http://www.ehelpinarhoteltorremolinos.com/</li>\r\n</ul>\r\n<p><span class="content_title">Допълнителни екскурзии в Коста Дел Сол <br /> </span>(по желание, срещу допълнително заплащане на място) <br /> <span class="content_title">ГРАНАДА. <br /> </span>За нея казват, че е един от най-красивите градове в света. Поети, музиканти, артисти са били вдъхновявани от Гранада. Интерес представляват Албисинския квартал, двореца Алхамбра &ndash; най-яркото произведение на арабското изкуство в Испания, впечатляващо съчетание на дворци и крепостни съоръжения. Посещава се &ldquo;залата на двете сестри&rdquo; и знаменития &ldquo;двор на лъвовете&rdquo;, които ще ни пренесат в 14 &ndash; ти век. Двореца на Карл V и Генералифските градини &ndash; лятната резиденция на древните испански крале с много фонтани. От тук можете да се насладите на прекрасна гледка към града. Oбяд в местен ресторант по желание срещу допълнително заплащане от 20 евро за възрастен и 15 евро за дете от 4 до 10 г. Свободно време. Завръщане в Коста дел Сол. <br /> <span class="content_title">СЕВИЛЯ. <br /> </span>Посещението започва с разглеждане на Royal Аlkazar &ndash; историческа сграда с впечатляващи зали, в които са представени произведения на изкуството. Разглежда се също Базиликата на Макарена и красивите мостове Аламило и Баркета. Пътуването включва посещение на Барио де Санта Круз, парка на Мария Луиза, булеварда на Палмите и Катедралата. Oбяд в местен ресторант по желание срещу допълнително заплащане от 20 евро за възрастен и 15 евро за дете от 2 до 10 г. На брега на река Гуадалкивир ще се полюбувате на Златната кула и на павилионите построени за &ldquo;Експо &ndash; 92&rdquo;. <br /> <span class="content_title">ТАНЖЕР. <br /> </span>Отпътуване от хотела в посока Алхесирас и Тарифа, от където с ферибот се пресича Гибралтарския проток. Пристигане в Танжер и екскурзия в околностите на града с автобус. Обяд в типичен ресторант, където ще Ви предложат типични за местната кухня блюда: харира, кус-кус, кефта, моруна, чай и сладкиши. Посещават се още сувенирни магазини. Завръщане в Алхесирас и Тарифа с ферибота и с автобус до курортите в Коста дел Сол. <br /> РОНДА. Разходка из живописното, типично испанско градче с посещение на катедралата, стария квартал, най-старата арена за корида и др. Допълнителните екскурзии включват екскурзоводско обслужване от страна на лицензирани екскурзоводи представители на испанската фирма контрагент, входни такси за посещаваните обекти, трансфери от и до хотела. <br /> Туроператора е сключил застрахователен договор с "ДЗИ - Общо застраховане" ЕАД&rdquo;, съгласно ПМС No 247 / 01.11.2002 г. - застрахователна полица No 212112213000001 от 30.11.2011 г. <br /> </p>\r\n<ul>\r\n<li>В програмите могат да участват всички желаещи &ndash; няма възрастови ограничения!</li>\r\n</ul>\r\n<p><span class="content_title">Посочените цени са валидни при резервация и 50 % капаро до 26.12.2011 г! <br /> </span><span class="content_title">От 27.12.2011, цените се увеличават със 100 лева на човек! </span></p>', 'Испания, Малага', '8 дни / 7 нощувки', 'Самолет', '425 €', '2012-06-29 10:56:18', 2, '2012-06-29 10:56:18', 2),
(51, 1, 13, 1, 'ПОЧИВКИ - Лято 2012 във ФЕТИЕ, Турция -7 нощувки -автобусна програма', '<p><strong>ФЕТИЕ е място за ценителите на качественото разтоварване.</strong><br />Разположен в западната част на залива Фетие, курортът предлага на своите гости уникална природа, която ще Ви накара да отпочинете истински сред планини, кедрови и елхови гори. Надарен с неповторим синхрон между планина и море, Фетие предлага плажове, които са изключителни &ndash; поддържани чисти и със златен пясък, те ще Ви накарат да изживеете дългоочакваната от Вас морска ваканция в Турция.<br />Фетие обаче има на разположение и друго предимство &ndash; многобройни хотели. Те са тихи и спокойни, какъвто е и целият курортен град, и ще Ви осигурят мечтаната почивка и уединение.</p>\r\n<p><strong>1''ви ден</strong><br />Тръгване в 12.30ч. от СофияТрафик маркет , 14.30ч. от Пловдив хотел &ldquo;Санкт Петербург&rdquo;. Отпътуване към границата, преминаване. Нощен преход. По обед пристигане в ФЕТИЕ. След 14.00 ч. настаняване в избрания хотел.</p>\r\n<p><strong>2''ри ден до 8''ми ден</strong><br />Свободно време и възможност за доп. екскурзии срещу заплащане предлагани от Турския партньор.</p>\r\n<p><strong>9''ти ден</strong><br />Освобождаване на хотела до 12.00 часа. Отпътуване за България.</p>\r\n<p><strong>10-ти ден</strong><br />По обед пристигане в България. Пловдив хотел &ldquo;Санкт Петербург&rdquo;, София ст. "Васил Левски" - малък мост</p>\r\n<p>В ПАКЕТНИТЕ ЦЕНИ Е ВКЛЮЧЕНО:<br />Транспорт с лицензирани комфортни автобуси за международен транспорт - в автобусите се предлагат студина напитка или минерална вода;</p>\r\n<p>7 нощувки в избрания хотел на съответната база във ФЕТИЕ;</p>\r\n<p>медицинска застраховка Асистънс на Булстрад / за лица над 65г. доплащане /;</p>\r\n<p>магистрални и фериботни такси;</p>\r\n<p>изпращане от представител при отпътуването на автобусите от София и Пловдив;</p>\r\n<p>обслужване от представител през цялото време на пътуването.</p>\r\n<p>посрещане на място в Турция от представител на фирмата партньор.</p>\r\n<p>НАСТАНЯВАНЕТО В АВТОБУСИТЕ СТАВА ПО РЕД НА ЗАПИСВАНЕ ЗА ГАРАНТИРАНИ ПРЕДНИ МЕСТА ОТ 1 ДО 12 СЕ ДОПЛАЩА!</p>\r\n<p>HB &ndash; (Закуска и вечеря).<br />ALL INCLUSIVE&ndash; (Храна и местни алкохолни и безалкохолни напитки).<br />ULTRA ALL INCLUSIVE &ndash; (Храна и местни и вносни алкохолни и безалкохолни напитки).</p>\r\n<p>Краен срок за уведомяване на потребителя, когато този брой не е набран: 10 дни преди датата на тръгване.</p>\r\n<p>УСЛОВИЯ ЗА РАННИ ЗАПИСВАНИЯ В ТУРЦИЯ!<br />1. Ранните записвания са валидни при резервация и плащане, направени до обявените промоционални дати!</p>\r\n<p>2. Всяка промяна на име на турист или дата на пътуване по резервация за ранно записване, се заплаща по съответната дата на стандартните цени!</p>\r\n<p>3. Всеки турист който резервирал и заплатил пакет за ранно записване в случай на отказ от пътуване и невъзможност да смени датата и заплати по основни тарифи губи на 100% внесената сума!</p>\r\n<p>ОБЩИ УСЛОВИЯ ПРИ ПЪТУВАНЕ И НАСТАНЯВАНЕ В КУРОРТИТЕ НА ТУРЦИЯ лято 2012!<br />1. Настаняването в хотелите при пристигане става след 14.00 часа, а освобождаването на стаите до 12.00 часа!</p>\r\n<p>2. При настаняването в хотели на база ALL INCLUSIVE (храна и местни алкохолни и безалкохолни напитки) храненията започват винаги от обяд или вечеря в зависимост от правилника на съответния хотел, никога не започват от закуска! Започването на даден пакет при настаняване с обяд, той приключва със закуска последния ден. При започването с вечеря, приключва с обяд!</p>\r\n<p>3. Преди настаняване в стаите и след освобождаване на същите не се ползват никакви услуги в хотелите или се ползват срещу заплащане!</p>\r\n<p>4. При настаняване на трима възрастни в стая с три легла, не се гарантират три оделни нормални легла, тъй като винаги третият възрастен ползва отстъпка от цената и затова се настанява на допълнително легло!</p>\r\n<p>5. Настаняването в стая с изглед към морето или в основна част на хотела става само в случаите където е обявено доплащане за това и съответно е заплатено предварително в офисите и представителствата.</p>\r\n<p>6. Туроператорът може да извърши замяна на хотела с такъв от същата или по-висока категория в същия курорт без промяна на общата цена заплатена от ПОТРЕБИТЕЛЯ, в случай на дублирана резервация, затваряне на съответния хотел, нежелание в последния момент хотела да приеме туристите.</p>\r\n<p>7. Точният час и място на отпътуване от България, номер на автобуса и съпровождащия водач се съобщават в ден сряда в седмицата на тръгване!</p>\r\n<p>8. Настаняването в автобусите е според датата на записване!</p>\r\n<p>9. Намаленията за деца са валидни само при настаняване с двама възрастни в стая.</p>\r\n<p>10. Всички деца имат седалка в автобуса!</p>\r\n<p>Туроператорът има сключена Застраховка &ldquo; Отговорност на туроператора&rdquo; полица № 3405081200R00095 г. на TBIH BULSTRAD Vienna Insurance Group, с адрес: София, пл. "Позитано" №5</p>', 'София - Фетие - София', '10 дни / 7 нощувки', 'Автобус', '430 лв.', '2012-06-29 11:17:22', 2, '2012-06-29 11:17:22', 2),
(52, 1, 17, 0, 'Aliquam nulla metus, dignissim eget semper nec', '<div id="lipsum">\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus iaculis hendrerit sem sed euismod. Nam egestas placerat lectus cursus aliquet. Praesent bibendum diam quis tortor ullamcorper sed vulputate nisl mattis. Sed suscipit justo eu urna elementum at bibendum metus venenatis. Sed sit amet eros lectus, ac molestie justo. Etiam vel justo vel justo commodo dignissim gravida eu nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vel massa mauris. Ut pulvinar, tellus at imperdiet sollicitudin, diam urna scelerisque velit, quis malesuada nisl sapien ut augue.</p>\r\n<p>Aliquam nulla metus, dignissim eget semper nec, blandit sed lorem. Nam purus tortor, congue a interdum at, tempus vitae nibh. Donec adipiscing, nibh at eleifend condimentum, ante sapien convallis velit, at consectetur leo neque in eros. Vivamus sodales felis nec nunc pretium placerat. Nulla nec mauris arcu, eu euismod arcu. Pellentesque quis sem magna, id dapibus mi. Vivamus ac ipsum ipsum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur sed neque est, eget lobortis felis. Phasellus quis mauris enim, vel pharetra dui. Aliquam erat volutpat.</p>\r\n<p>Ut sodales, arcu non ornare vehicula, dolor sapien egestas erat, in iaculis nibh mi in eros. Quisque nec lorem ante. Curabitur vel mi leo. Suspendisse vitae accumsan dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam pellentesque ipsum eu magna bibendum dictum. Donec mollis dignissim risus sit amet aliquam. Nulla purus sem, consectetur sed vulputate a, suscipit et tortor.</p>\r\n<p>Fusce risus nunc, vehicula vitae molestie sit amet, vestibulum ut nibh. Sed aliquam urna eu diam volutpat consectetur pharetra dolor viverra. Aenean dapibus, neque eget congue eleifend, elit magna semper lacus, eu gravida odio nulla in elit. Proin at accumsan nulla. Suspendisse ac enim id dolor sollicitudin feugiat. Ut eget mauris odio, sed placerat libero. Ut eleifend lectus ac mi ultricies sodales. Duis eleifend tincidunt tellus ut luctus.</p>\r\n<p>Ut facilisis, sem a vestibulum feugiat, nisl orci gravida est, eget laoreet ligula arcu a metus. Duis sed neque sed neque venenatis volutpat ultricies et arcu. Suspendisse mattis quam ac tortor tincidunt ut consequat justo adipiscing. Vivamus euismod urna nec tortor aliquam iaculis. Phasellus est metus, suscipit vitae ultrices in, auctor a tortor. Aliquam lobortis mattis enim, quis iaculis massa consequat ac. Duis leo felis, adipiscing at mattis et, porta non libero. Maecenas non ante quam, hendrerit suscipit tellus.</p>\r\n</div>', '', '', '', '', '2012-06-29 11:40:32', 2, '2012-06-30 10:06:53', 2);
INSERT INTO `offers` (`id`, `lang_id`, `category_id`, `vip_offer`, `name`, `content`, `route`, `duration`, `transport`, `price`, `added`, `added_by`, `modified`, `modified_by`) VALUES
(53, 3, 25, 1, 'Остров Крък, Хърватия 55+ приятели', '<p><span class="content_title">"ОСТРОВ КРЪК, ХЪРВАТИЯ 55+ И ПРИЯТЕЛИ&rdquo; <br /> </span>с автобус, 5 нощувки, 7 дни <br /> <br /> <span class="content_title">Дати на заминаване: <br /> </span>07, 14, 21 и 28 април, <br /> 05, 12 и 19 май, <br /> 08, 15, 22 и 29 септември 2012 <br /> <br /> <br /> <span class="content_title">1 ДЕН &ndash; София - Крък <br /> </span>Отпътуване от София в 22:00 ч. от стадион &ldquo;Васил Левски&rdquo; по маршрут: София - Белград &ndash; Загреб &ndash; остров Крък. <br /> <br /> <span class="content_title">2 ДЕН- Крък <br /> </span>Пристигане на остров Крък. Настаняване в избрания хотел в Пунат или Башка. Свободно време за почивка. Вечеря. Нощувка. <br /> <br /> <span class="content_title">3 ДЕН - Крък <br /> </span>Закуска. Свободно време за плаж, развлечения или Обзорна екскурзия на острова (срещу допълълнително заплащане). <br /> Започваме с разходката с обиколка на Башка с малките криволичещи улички по хълмистото градче, продължаваме до романтичният Пунат с една от най-големите марини на Адриатическото крайбрежие. Задължително посещаваме и единствения населен остров в този архипелаг- Кошлюн. Кошлюн е много малък остров, но много богат на история-тук са Францисканския манастир и 100-годишното училище с много богати исторически колекции. Връщаме се на основния о-в Крък с лодка и се отправяме към столицата Крък, за да се на сладим на духа останал от Средновековието. А за последно оставяме малкият Връбник, кацнал на 50-метрова скала. <br /> Вечеря в хотела. Нощувка. <br /> <br /> <span class="content_title">4 ДЕН - Крък &ndash; Плитвички езера <br /> </span>Закуска. Свободно време за плаж, развлечения или допълнителна екскурзия до Плитвичките езера (срещу допълълнително заплащане). <br /> Плитвички езера е най-големия национален парк в Хърватия, а от 1979 г. е включен в списъка на световното културно наследство на ЮНЕСКО . Разходката в самия парк е по един от определените маршрути с електрически корабчета, влакчета и пеша. Трудно е да се опише красотата на парка, където са събрани множество водопади и езера, а цветовете им се сменят от небесно синьо до смарагдово зелено. <br /> Вечеря в хотела. Нощувка. <br /> <br /> <span class="content_title">5 ДЕН - Крък - Риека <br /> </span>Закуска. Свободно време за плаж, развлечения или допълнителна екскурзия до Риека (срещу допълълнително заплащане). <br /> Риека е главно пристанище и се намира в сърцето на залива Кварнер. Започваме тура от Корзо-пешеходна улица в старата част на града, за да разгледаме Старата Порта, бившата йезуитска ротонда а сега църква Св.Вито, хърватския национален театър и кулата на градския часовник. Следобяд ще посетим двореца Търсат-построен през XIII в. от династията на Франкопаните. <br /> Вечеря в хотела . Нощувка. <br /> <br /> <span class="content_title">6 ДЕН - Крък <br /> </span>Закуска. Свободно време за плаж и развлечения на о-в Крък. Обяд и вечеря, нощувка в хотела. <br /> <br /> <span class="content_title">7 ДЕН - Крък - Загреб - София <br /> </span>Закуска. Освобождаване на хотела и отпътуване за България. Пауза в Загреб и възможност за разглеждане на стария град &bdquo;Горен Загреб&rdquo; - от площад Йелачица до каменната порта.. Пристигане в София на другия ден сутринта. <br /> <br /> <span class="content_title">РАННИ ЗАПИСВАНИЯ ДО 31.01.2012г &ndash; безплатна Обзорна екскурзия на остров Крък! <br /> </span> <br /> <span class="content_title">ХОТЕЛ PARK PUNAT 3*/economy room/ <br /> </span>http://www.hoteli-punat.hr/ </p>\r\n<table class="wiki_table" border="0" cellspacing="0" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td class="wiki_td">дата</td>\r\n<td class="wiki_td">цена на човек в двойна стая</td>\r\n<td class="wiki_td">единична стая</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td">07.04-14.04, 14.04-21.04, 21.04-28.04, 28.04-05.05, 05.05-12.05</td>\r\n<td class="wiki_td">535 лева</td>\r\n<td class="wiki_td">620 лева</td>\r\n</tr>\r\n<tr>\r\n<td class="wiki_td">12.05-19.05, 19.05-26.05, 08.09-15.09, 15.09-22.09, 22.09-29.09, 29.09-06.10</td>\r\n<td class="wiki_td">590 лева</td>\r\n<td class="wiki_td">680 лева</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Настаняване на трети вързастен в двойна стая или дете до 12г. с двама възрастни в стая - на запитване. <br /> <br /> <span class="content_title">Цената е в лева на човек и включва: <br /> </span>&bull; 5 нощувки на пансион закуска, обяд и вечеря с включени минерална вода и вино (за обяд и вечеря); <br /> &bull; пешеходна разходка в старата част на Загреб; <br /> &bull; транспорт с комфортен автобус от София; <br /> &bull; водач от туроператора по време на цялото пътуване; <br /> &bull; медицинска застраховка &bdquo;Помощ при пътуване&rdquo;с покритие 5000 евро. <br /> <br /> <span class="content_title">Цената не включва: <br /> </span>&bull; лични разходи; <br /> &bull; допълнителни екскурзии. <br /> <br /> <span class="content_title">ЦЕНИ НА ДОПЪЛНИТЕЛНИТЕ ЕКСКУРЗИИ: <br /> </span>1. Остров Крък-обзорна обиколка <br /> Цена възрастен -15 евро; Дете (02-11,99г) 10 евро <br /> Маршрут: Башка-Пунат-о-в Кошлюн-гр.Крък-Връбник-Башка <br /> Продължителност: 4-5 часа <br /> <br /> 2. Плитвички езера-с включена входна такса <br /> Цена възрастен -38 евро; Дете (02-11,99г) 30 евро <br /> Маршрут: Башка-Плитвишки езера-Башка <br /> Продължителност: 7-8 часа <br /> <br /> 3. Риека <br /> Цена възрастен -22 евро; Дете (02-11,99г) 17 евро <br /> Маршрут: Башка-Пунат-Риека-Пунат-Башка <br /> Продължителност: 5-6 часа <br /> <br /> УСЛОВИЯ ЗА ЗАПИСВАНЕ ПО ПРОГРАМАТА: <br /> &bull; авансово плащане &ndash; 30 % от пакетната цена при записване. Резервацията ще се счита за гарантирана след подписване на договор за организирано туристическо пътуване с клиент и заплащане на авансовата сума до 48 ч след потвърждението. След този срок резервацията автоматично ще бъде анулирана. <br /> &bull; доплащане &ndash; до 14 дни преди датата на отпътуване. <br /> &bull; няма възрастови ограничения за записване по програмата. <br /> &bull; при резервацията по ранно записване не се допускат промени или анулации. При анулирана резервация от стран ана клиента по ранно записване депозитът се удържа в цялата си сума. <br /> &bull; Минимален брой участници за провеждане на екскурзията 35 туриста. <br /> &bull; Краен срок за уведомление за провеждане на екскурзията 10 дни преди заминаване. <br /> &bull; Туроператорът не носи отговорност и не възстановява суми на туристи, на които им се отказва достъп до Хърватия поради: забрана за напускане на страната, невалидни /забравени/ документи или други независещи от туроператора причини. <br /> &bull; Необходими документи: лична карта или международен паспорт, с 6 (шест) месечна валидност от датата на отпътуване. <br /> &bull; При пътуване на непълнолетни лица до 18 години без родители или само с един родител, спорeд новите изисквания на Хърватия- съгласно чл. 8 на закона за чужденците на Р. Хърватия, се изисква същите да притежават нотариално заверено разрешение за пътуване (декларация). Разрешението трябва да бъде на български език (оригинал и копие) и в превод на хърватски или на английски език (оригинал и копие) <br /> &bull; Няма допълнителни визови, санитарни и медицински изисквания за влизане в страната. <br /> &bull; туроператорът си запазва правото да промени цената в случай на драстично увеличение цената на горивата и др. (01.12.2011 г) <br /> &bull; Намаленията за деца са валидни само при настаняване с двама пълноплащащи в стая. <br /> &bull; Настаняването в тройни стаи не гарантира 3 отделни и нормални легла. <br /> &bull; Стаи с изглед към морето, се гарантират само в хотелите, в които има обявено доплащане за това. <br /> &bull; Настаняването в хотелите е след 14.00 часа в деня на пристигане, а освобождаването на стаите е до 12.00 часа в деня на заминаване. <br /> &bull; Преди настаняване в стаите и след освобождаване на същите не се ползват никакви услуги в хотелите или се ползват срещу заплащане. <br /> &bull; Точният час на отпътуване за България се съобщават в деня на пристигане в Хърватия от представителя на туроператора, който придружава групата. <br /> &bull; В случай на отказ от пътуването и прекратяване на договора от страна на потребителя, следват следните неустойки: <br /> 1. от 44 до 28 дни преди началото на екскурзията 30% от цената на пътуването; <br /> 2. от 27 до 14 дни преди началото на екскурзията 50% от цената на пътуването; <br /> 3. от 14 до 7 дни преди началото на екскурзията 80% от цената на пътуването; <br /> 4. след 7-мия ден преди началото на екскурзията 100% от цената на пътуването; <br /> <br /> ЗАЩО ОСТРОВ КРЪК, ХЪРВАТИЯ? <br /> <br /> Остров Крък е: <br /> Най-големият остров на Адриатика; <br /> Най-северният остров на Адриатика; <br /> Най-достъпният остров на Адриатика; <br /> Най-разнообразният остров на Адриатика; <br /> Най-посещаваният остров на Адриатика; <br /> <br /> Остров Крък е най-големият остров на Хърватия с площ 409 кв.км и се намира в залива Кварнер на Адриатическо море. Южната част на острова е по-заселена, а и по-плодородна. Там е разположен и плажът Башка - един от редките пясъчни плажове в Хърватия. В центъра на острова се намира средновековния град Крък и малкия Връбник известен като център на производство на известното вино Златина. Град Крък е икономически и административен център на острова повече от 3000 години. Известен е със запазените си крепостни стени и Франкопанския замък. Връбник е уникално градче, което притежава рядка красота. Когато навлезете сред старите къщи и тесните криволичещи улички, без дори и да усетите ще се върнете стотици години назад във времето. <br /> Башка е най-южната точка на острова и ежегодно привлича посетители от цял свят.&ldquo;Baska Blue Bar" на Башка плаж е обявен за един от десетте най-добри барове на плажа от британския "Таймс Онлайн". Дълъгият и красив плаж, и множеството възможности за развлечения са само някои от причините да дойдете тук, а красотата на заобикалящата ви природа, е неповторима със спиращите дъха заливи и очарователни морски гледки. <br /> Не е необходимо да знаете нещо за историята на Хърватия и на остров Крък, защото веднага след като пристигнете, ще осъзнаете, че тя се разкрива пред вас с всяка направена крачка... <br /> Остров Крък, Хърватия е едно пътуване през времето, което няма да забравите никога!</p>', 'София - Крък - София', '7 дни / 5 нощувки', 'Автобус', '535 лв.', '2012-07-03 14:08:54', 2, '2012-07-03 14:08:54', 2),
(54, 2, 22, 1, 'Tailor-made tours Bulgaria, Romania, Turkey, etc.', '<p>Itineraries for all budgets: mountains, seaside, spa, picturesque villages and towns, traditions...</p>\r\n<p>&nbsp;</p>\r\n<p><strong><em>Special interest programs and round trips in English, French, Russian, German, Spanish, Italian, Portuguese, Greek, Hungarian, Dutch, Chinese or language upon request:</em></strong></p>\r\n<p>&nbsp;</p>\r\n<p>- - Short tours: Sofia, Rila Monastery, Melnik, Plovdiv, Koprivshtitsa, Bansko, etc.<br />- - Classic Bulgaria<br />- - Monasteries, Museum towns and villages<br />- - UNESCO sites<br />- - History and archaeology<br />- - Music, arts and architecture<br />- - Folklore, traditions, crafts<br />- - Wine and dine tours<br />- - Rail and retro tram tours<br />- - Festivals, including the Festival of Roses and Koprivshtitsa International Folklore Festival<br />- - Combined tours: Bulgaria + Romania, Macedonia, Albania, Hungary, Turkey, Greece, Serbia, Croatia, Czech Republic, etc.<br />- - Bird watching, nature and natural phenomena, etc.</p>\r\n<p>&nbsp;</p>\r\n<p>Self-drive itineraries, spa and sea, etc....</p>\r\n<p>&nbsp;</p>', '', '2 days', '', '30 euro per person', '2012-07-03 14:46:22', 2, '2012-07-03 14:46:30', 2),
(55, 2, 22, 1, 'Self Drive Holiday in Bulgaria: 14 days', '<p>Mountains, seaside, picturesque villages and towns, national-style restaurants, traditions... Package: rent-a-car + pensions and guest houses accommodation Class B car: 390 euro per pers in dbl, Class C car, A/C: 415 euro per pers in dbl room</p>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td width="15%">trip</td>\r\n<td width="85%">\r\n<h1>&nbsp;</h1>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day1</p>\r\n</td>\r\n<td width="85%">\r\n<p>Arrival Sofia Airport. Pick up of the car and departure to the Rila Mountains - the village of Beli Iskar - just a few km from the biggest mountain resort in Bulgaria (Borovets) and 75 km from Sofia.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day2</p>\r\n</td>\r\n<td width="85%">\r\n<p>Departure south to Rila Monastery, via Sandanski to Melnik - the smallest Bulgarian town, centre of red wines.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day3</p>\r\n</td>\r\n<td width="85%">\r\n<p>Day to enjoy the region. Possible walking tour to Rojen Monastery (10th c) and Rojena village. Wonderful panorama towards the Greek border, which is just a few km away and all the mountains.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day4</p>\r\n</td>\r\n<td width="85%">\r\n<p>Continue your journey west, via Mountain roads to the town of Gotse Delchev and the small villages scattered in the mountains. from the main road, or to Dospat dam. Continue to Shiroka Luka museum village.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day5</p>\r\n</td>\r\n<td width="85%">\r\n<p>Dedicate the day to the Rhodope mountains - visit Trigrad Gorge, the caves.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day6</p>\r\n</td>\r\n<td width="85%">\r\n<p>Depart from Shiroka Luka north to Assenova Fortress, Bachkovo Monastery (the 2nd largest in Bulgaria ) and Plovdiv.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day7</p>\r\n</td>\r\n<td width="85%">\r\n<p>Dedicate the day to Plovdiv - the 2nd largest city in Bulgaria and rival of Sofia - visit the Old town, the Roman Amphitheatre, the Etnographic museum, etc.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day8</p>\r\n</td>\r\n<td width="85%">\r\n<p>Depart towards the Black Sea coast. Arrival in the town of Nessebur ( UNESCO world heritage site )</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day9</p>\r\n</td>\r\n<td width="85%">\r\n<p>Day to enjoy the sea and the beach.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day10</p>\r\n</td>\r\n<td width="85%">\r\n<p>Departure to Central Bulgaria - visit Kotel and Jeravna museum towns ( main centres of carpet weaving ).</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day11</p>\r\n</td>\r\n<td width="85%">\r\n<p>Depart to Kazanluk, Shipka peak to Triavna, Veliko Turnovo, Arbanassi museum village.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day12</p>\r\n</td>\r\n<td width="85%">\r\n<p>Day dedicated to Veliko Turnovo and the region.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day13</p>\r\n</td>\r\n<td width="85%">\r\n<p>Departure to Sofia. Full day in the capital city of Bulgaria.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="15%">\r\n<p>day14</p>\r\n</td>\r\n<td width="85%">\r\n<p>Departure.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '', '14 days', '', '390 euro p.p.', '2012-07-03 14:48:08', 2, '2012-07-03 14:48:20', 2);

-- --------------------------------------------------------

--
-- Table structure for table `offers_periods`
--

DROP TABLE IF EXISTS `offers_periods`;
CREATE TABLE IF NOT EXISTS `offers_periods` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offer_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `offers_periods`
--

INSERT INTO `offers_periods` (`id`, `offer_id`, `date`) VALUES
(44, 50, '2012-09-21'),
(45, 51, '2012-08-31');

-- --------------------------------------------------------

--
-- Table structure for table `offers_pictures`
--

DROP TABLE IF EXISTS `offers_pictures`;
CREATE TABLE IF NOT EXISTS `offers_pictures` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `offer_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `offers_pictures`
--

INSERT INTO `offers_pictures` (`id`, `offer_id`, `filename`, `date`) VALUES
(45, 47, 'FLORENCIQ1.jpg', '2012-06-29 10:28:44'),
(46, 47, 'FLORENCIQ2.jpg', '2012-06-29 10:28:44'),
(47, 47, 'FLORENCIQ3.jpg', '2012-06-29 10:28:44'),
(48, 47, 'FLORENCIQ4.jpg', '2012-06-29 10:28:44'),
(49, 47, 'OMG.jpg', '2012-06-29 10:28:44'),
(50, 48, 'IMG_1430.jpg', '2012-06-29 10:32:27'),
(51, 48, 'Kate-Paccioretti-Duomo1.jpg', '2012-06-29 10:32:27'),
(52, 48, 'la-scala-di-milano-modello-1-a-20-secondo-il-progetto-del-piermarini-257040617.jpg', '2012-06-29 10:32:27'),
(53, 48, 'milano-cavallo-leonardo2.jpg', '2012-06-29 10:32:27'),
(54, 49, 'RIM1.jpg', '2012-06-29 10:35:59'),
(55, 49, 'RIM2.jpg', '2012-06-29 10:35:59'),
(56, 49, 'RIM3.jpg', '2012-06-29 10:35:59'),
(57, 49, 'RIM4.jpg', '2012-06-29 10:35:59'),
(58, 49, 'RIM5.jpg', '2012-06-29 10:35:59'),
(59, 49, 'RIM6.jpg', '2012-06-29 10:35:59'),
(60, 50, 'Costa-Del-Sol_0.jpeg', '2012-06-29 10:56:18'),
(61, 50, 'Costa-Del-Sol_1.jpeg', '2012-06-29 10:56:18'),
(62, 50, 'Costa-Del-Sol_2.jpeg', '2012-06-29 10:56:18'),
(63, 50, 'Costa-Del-Sol_3.jpeg', '2012-06-29 10:56:18'),
(64, 51, 'Fethiye_0.jpg', '2012-06-29 11:17:22'),
(66, 53, '1.jpg', '2012-07-03 14:08:54'),
(67, 53, 'croatia1.jpg', '2012-07-03 14:08:54'),
(68, 53, 'croatia3.jpg', '2012-07-03 14:08:54'),
(69, 53, 'Krka2.jpg', '2012-07-03 14:08:54'),
(70, 53, 'Rijeka.jpg', '2012-07-03 14:08:54'),
(71, 53, 'Zagreb.jpg', '2012-07-03 14:08:54'),
(72, 54, '01_lage-berlin1.jpg', '2012-07-03 14:46:22'),
(73, 54, '1289.jpeg', '2012-07-03 14:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `scripts`
--

DROP TABLE IF EXISTS `scripts`;
CREATE TABLE IF NOT EXISTS `scripts` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `title` varchar(32) NOT NULL,
  `name` varchar(48) NOT NULL,
  `has_offers` tinyint(3) unsigned NOT NULL,
  `version` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `scripts`
--

INSERT INTO `scripts` (`id`, `title`, `name`, `has_offers`, `version`) VALUES
(1, 'Стандартна страница', 'article.php', 0, 0),
(2, 'Оферти', 'offers.php', 1, 1),
(3, 'Контакт формуляр', 'contacts.php', 0, 0),
(5, 'Начална страница', 'home.php', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `default` varchar(255) NOT NULL,
  `type` enum('integer','string','boolean') NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`name`, `value`, `default`, `type`, `description`) VALUES
('copyright', '2012', '2012', 'string', 'Година за авторски права'),
('country', 'BG', 'BG', 'string', 'Локализация: Държава'),
('debug', 'false', 'false', 'boolean', 'Режим на дебъгване'),
('language', 'bg', 'bg', 'string', 'Локализация: Език'),
('lastupdate', '1', '1', 'integer', 'Последна версия на CSS/JavaScript (кеш)'),
('locale', 'bg_BG', 'bg_BG', 'string', 'Локализация: Локал низ (нужен за Gettext())'),
('login.timeout', '2700', '2700', 'integer', 'Време в секунди преди автоматичен изход от системата'),
('mail.contact', 'office@arkaintour.com', 'office@fantastictravel.bg', 'string', 'Мейл на който да се пращат писмата от контакт формуляра'),
('mail.contact.name', '', '', 'string', 'Мейл, име към mail.contact'),
('mail.offers', 'office@arkaintour.com', 'office@fantastictravel.bg', 'string', 'Мейл на който да се пращат писмата от запитванията на офертите'),
('mail.offers.name', '', '', 'string', 'Мейл, име към mail.offers'),
('paging.count', '25', '25', 'integer', 'Странициране, брой резултати на страница.'),
('paging.groups', '7', '7', 'integer', 'Странициране, максимален брой на показаните страници наведнъж'),
('smtp.authtype', 'tls', '', 'string', 'SMTP мейл, тип на удостоверяването (шифрована връзка)'),
('smtp.codepage', 'UTF-8', 'UTF-8', 'string', 'SMTP мейл, подразбираща се кодова таблица за мейлите'),
('smtp.hostname', 'nasbg.com', 'localhost', 'string', 'SMTP мейл, име на хост'),
('smtp.hostport', '26', '25', 'integer', 'SMTP мейл, порт за достъп'),
('smtp.is_auth', 'true', 'false', 'boolean', 'SMTP мейл, удостоверяване с парола и потребителско име'),
('smtp.password', 'zuy!dDwMmS}B', '', 'string', 'SMTP мейл, Парола за удостоверяване'),
('smtp.username', 'noreply@nasbg.com', '', 'string', 'SMTP мейл, Потребителско име за удостоверяване');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `session_id` char(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` char(32) NOT NULL,
  `salt` char(12) NOT NULL,
  `added` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `session_id`, `name`, `username`, `password`, `salt`, `added`, `modified`) VALUES
(1, '0ds3rvl2k6hrgrjmlmuimc4aa27ditq2', 'Admin', 'admin', '30d1a5a3538e59de05a2ee413787f09f', 'Fy&}ZL8JE%w[', '0000-00-00 00:00:00', '2012-03-28 19:36:04'),
(2, 'eo3i9vib2tll39nb866hqrd3qlcof17o', 'User', 'user', 'b5343940cb4fd72348e4991f7da59905', 'Yqbv7k[]Mt]5', '0000-00-00 00:00:00', '2012-07-03 13:48:21');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
